#!/bin/bash
BASE="$HOME/Library/Application Support"
find "$BASE" -maxdepth 4 -path "*NativeMessagingHosts/com.hanyoung.auto.json" -delete 2>/dev/null
rm -rf "$BASE/HanYoungAuto"
echo "도우미를 지웠어요."
