#!/bin/bash
# 한영 자동전환 도우미 설치 (맥)
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/Library/Application Support/HanYoungAuto"
echo "한영 자동전환 도우미를 설치해요..."
mkdir -p "$APP"; rm -rf "$APP/helper"; cp -R "$SRC/helper" "$APP/helper"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
chmod +x "$APP/helper/hanyoung-host" "$APP/helper/macism"
MANIFEST='{"name":"com.hanyoung.auto","description":"HanYoung Auto helper","path":"'"$APP/helper/hanyoung-host"'","type":"stdio","allowed_origins":["chrome-extension://ijopdgicjgmmbibedclnnoacbfekfjlk/", "chrome-extension://djgjablbbcadaaeeooiflhdhkkgening/"]}'
BASE="$HOME/Library/Application Support"
for t in "Google/Chrome" "Google/Chrome Beta" "Chromium" "Microsoft Edge" "BraveSoftware/Brave-Browser" "Arc/User Data" "Vivaldi" "Naver/Whale" "Aside"; do
  if [ -d "$BASE/$t" ] || [ "$t" = "Google/Chrome" ]; then
    mkdir -p "$BASE/$t/NativeMessagingHosts"
    echo "$MANIFEST" > "$BASE/$t/NativeMessagingHosts/com.hanyoung.auto.json"
    echo "  연결됨: $t"
  fi
done
echo ""
echo "설치 완료! 브라우저를 ⌘Q로 완전히 껐다 다시 켜 주세요."
