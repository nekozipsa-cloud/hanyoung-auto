한영 자동전환 도우미 (맥)

터미널에서 bash 를 입력하고 install.command 를 끌어다 놓은 뒤 엔터.
브라우저를 ⌘Q로 껐다 켜세요.
자세한 안내: https://nekozipsa-cloud.github.io/hanyoung-auto
