﻿한영 자동전환 도우미 (윈도우)

install.bat 을 더블클릭하고 브라우저를 껐다 켜세요.
자세한 안내: https://nekozipsa-cloud.github.io/hanyoung-auto
