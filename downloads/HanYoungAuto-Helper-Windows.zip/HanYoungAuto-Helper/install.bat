@echo off
chcp 65001 >nul
setlocal
set "SRC=%~dp0"
set "APP=%LOCALAPPDATA%\HanYoungAuto"
echo 한영 자동전환 도우미를 설치해요...
if exist "%APP%\helper" rmdir /s /q "%APP%\helper"
if not exist "%APP%" mkdir "%APP%"
xcopy "%SRC%helper" "%APP%\helper\" /e /i /q /y >nul
powershell -NoProfile -Command "Get-ChildItem -Recurse -LiteralPath (Join-Path $env:LOCALAPPDATA 'HanYoungAuto') | Unblock-File" >nul 2>&1
set "MANI=%APP%\helper\com.hanyoung.auto.json"
for %%K in ("Google\Chrome" "Microsoft\Edge" "Chromium" "BraveSoftware\Brave-Browser" "Naver\Whale") do (
  reg add "HKCU\Software\%%~K\NativeMessagingHosts\com.hanyoung.auto" /ve /t REG_SZ /d "%MANI%" /f >nul
)
echo.
echo 설치 완료! 브라우저를 완전히 껐다 다시 켜 주세요.
echo 확장 프로그램 아이콘을 눌러 '도우미 연결됨'이 보이면 끝이에요.
pause
