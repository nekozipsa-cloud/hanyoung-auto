@echo off
chcp 65001 >nul
for %%K in ("Google\Chrome" "Microsoft\Edge" "Chromium" "BraveSoftware\Brave-Browser" "Naver\Whale") do (
  reg delete "HKCU\Software\%%~K\NativeMessagingHosts\com.hanyoung.auto" /f >nul 2>&1
)
rmdir /s /q "%LOCALAPPDATA%\HanYoungAuto" >nul 2>&1
echo 도우미를 지웠어요.
pause
